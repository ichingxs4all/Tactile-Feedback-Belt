Aannemende dat je node al ge�nstalleerd hebt:
Eerst even 'npm install' draaien vanuit je console in deze directory om de 'serialport' package binnen te trekken.