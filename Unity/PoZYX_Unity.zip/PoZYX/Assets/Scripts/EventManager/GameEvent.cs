﻿using UnityEngine.Events;

namespace Core {
	class GameEvent : UnityEvent<object[]> {
	}
}