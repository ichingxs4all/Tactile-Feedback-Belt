using UnityEngine;
using Feature.Networking;

public class POZYX_Parser : MonoBehaviour {
	[SerializeField] private NetworkingDataModel networkData;

	//public StringVariable UDP_Message;
	public POZYXVariable PoZYX;

	private void Update() {
		if (networkData.dataString.Length != 0)
		{
			string[] words = networkData.dataString.Split(',');
			float newX = float.Parse(words[0]);
			float newY = float.Parse(words[1]);
			float newZ = float.Parse(words[2]);

			PoZYX.x = newX / 100;
			PoZYX.y = newY / 100;
			PoZYX.z = newZ / 100;

			PoZYX.yaw = float.Parse(words[3]);
			PoZYX.roll = float.Parse(words[4]);
			PoZYX.pitch = float.Parse(words[5]);
			
			Debug.Log("PoZYX = " + "X = " + PoZYX.x + " Y = " + PoZYX.y + " Z = " + PoZYX.z + " Yaw = " + PoZYX.yaw + " Roll = " + PoZYX.roll + " Pitch = " + PoZYX.pitch );
			//PoZYX.y = 2;// / 100;
		}
	}
}
