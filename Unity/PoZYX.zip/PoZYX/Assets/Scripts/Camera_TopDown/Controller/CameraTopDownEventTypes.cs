﻿namespace Feature.CameraTopDown {
    public class CameraTopDownEventTypes {
        private const string PREFIX = "CAMERA_TOP_DOWN_";
        
        /// <summary>
        /// Arguments: -
        /// </summary>
        public const string TURN_CAMERA = "TURN_CAMERA";
    }
}